package com.example.myapplication

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.EditText

class loginn : AppCompatActivity() {
    lateinit var email:EditText
    lateinit var password:EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loginn)
        email=findViewById(R.id.email)
        password=findViewById(R.id.pssword)
    }

    fun perehod(view: View) {
        if(email.text.toString().isNotEmpty()&&password.text.toString().isNotEmpty())
        {
            val intent=Intent(this,main::class.java)
            startActivity(intent)
        }
        else{
            var alert=AlertDialog.Builder(this)
                .setTitle("Ошибка")
                .setMessage("У вас есть не заполненый поля")
                .setPositiveButton("Ok",null)
                .create()
                .show()
        }
    }


}